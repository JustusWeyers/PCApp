#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @useDynLib PCApp, .registration = TRUE
## usethis namespace: end
NULL

## usethis namespace: start
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL
